////////////////////////////////////////////////////////////////////////////////
/// @file 7_series_ahrs_example.c
///
/// @defgroup _7_series_ahrs_example_c 7-Series AHRS Example [C]
///
/// @ingroup examples_c
///
/// @brief Example setup program for the 3DM-CV7-AHRS, and 3DM-GV7-AHRS using C
///
/// @details This example shows a basic setup to configure the attitude filter
///          with magnetometer as the heading source to stream filter data for
///          the 3DM-CV7-AHRS, and 3DM-GV7-AHRS using C. This is not an
///          exhaustive example of all settings for those devices. If this
///          example does not meet your specific setup needs, please consult the
///          MIP SDK API documentation for the proper commands.
///
/// @section _7_series_ahrs_example_c_license License
///
/// @copyright Copyright (c) 2025 MicroStrain by HBK
///            Licensed under MIT License
///
/// @{
///

// Include the MicroStrain Serial connection header
#include <microstrain/connections/serial/serial_port.h>

// Include the MicroStrain logging header for custom logging
#include <microstrain/logging.h>

// Include all necessary MIP headers
// Note: The MIP SDK has headers for each module to include all headers associated with the module
// I.E., #include <mip/mip_all.h>
#include <mip/mip_interface.h>
#include <mip/definitions/commands_3dm.h>
#include <mip/definitions/commands_base.h>
#include <mip/definitions/commands_filter.h>
#include <mip/definitions/data_sensor.h>
#include <mip/definitions/data_filter.h>
#include <mip/definitions/data_shared.h>

#ifdef _MSC_VER
#define _USE_MATH_DEFINES
#endif // _MSC_VER

#include <math.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdint.h>    
#include <inttypes.h>

#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <dirent.h>


////////////////////////////////////////////////////////////////////////////////
// NOTE: Setting these globally for example purposes

/*********************************************************************
 * DEFINES
 */

#define CAPTURE_DURATION_TIME 20000 // Time en ms to capture Gyro Bias
#define MAGNETOMETER_FEATURE 0 // Set to 1 to include magnetometer data and AHRS mode, set to 0 to exclude magnetometer data and use vertical gyro mode

#define MAX_FILENAME_LENGTH 150 // Buffer size for file name
#define BUFFER0_SIZE 200 // Buffer size for SensorConnectData
#define BUFFER1_SIZE 100 // Buffer size for QuaternionData
#define BUFFER2_SIZE 100 // Buffer size for QuaternionEstData


#define INDIVIDUAL_SCRIPT 1 // Set this option to enable individual script testing
#define MAX_PATH 512


#define DEFAULT_CONFIG 1 // Set this option to configure the device with the default settings for the 7-Series AHRS devices. 

#define SC_CONFIG  1 // Set this option to configure the device with the settings used for the SensorConnect application.

/*********************************************************************
 * CONSTANTS
 */

// TODO: Update to the correct port name and baudrate
/// @brief  Set the port name for the connection (Serial/USB)
#ifdef _WIN32
static const char* PORT_NAME = "COM1";
#else  // Unix
//static const char* PORT_NAME = "/dev/ttyUSB1";
#endif // _WIN32

/// @brief  Set the baudrate for the connection (Serial/USB)
/// @note For native serial connections this needs to be 115200 due to the device default settings command
/// Use mip_base_*_comm_speed() to write and save the baudrate on the device
static uint32_t BAUDRATE = 0;
//static const uint32_t BAUDRATE = 115200;
// TODO: Update to the desired streaming rate. Setting low for readability purposes
/// @brief Streaming rate in Hz (applies to both sensor and filter data)
static uint16_t SAMPLE_RATE_HZ = 270;

/// @brief OPTIONAL: Set specific sensor decimation (0 = auto-calculate from SAMPLE_RATE_HZ)
/// Use this only if you want a different rate for sensor data than filter data
//static uint16_t SENSOR_DECIMATION = 0;  // 0 = use SAMPLE_RATE_HZ

/// @brief OPTIONAL: Set specific filter decimation (0 = auto-calculate from SAMPLE_RATE_HZ)
/// Use this only if you want a different rate for filter data than sensor data
//static uint16_t FILTER_DECIMATION = 0;  // 0 = use SAMPLE_RATE_HZ

// TODO: Update to change the example run time
/// @brief Example run time
static const uint32_t RUN_TIME_SECONDS = 10*60*60;


/*********************************************************************
 * GLOBAL VARIABLES
 */ 


char buffer0[BUFFER0_SIZE]; // buffer for SensorConnectData

char buffer1[BUFFER1_SIZE];  // buffer for QuaternionData

char buffer2[BUFFER2_SIZE];  // buffer for QuaternionEstData

int fileSetCounter = 1; // Contador global para los archivos

static bool flagStop = false; 

// Sensor Data
mip_dispatch_handler sensor_data_handlers[5];

//Device data stores
mip_shared_gps_timestamp_data        sensor_gps_timestamp    = {0};
mip_sensor_scaled_accel_data         sensor_accel_scaled     = {0};
mip_sensor_delta_velocity_data       sensor_delta_velocity   = {0};
mip_sensor_comp_quaternion_data      sensor_quaternion       = {0};
mip_shared_reference_timestamp_data  sensor_inTime    = {0};


mip_dispatch_handler filter_data_handlers[6];

// Data stores for filter data
mip_shared_gps_timestamp_data               filter_gps_timestamp        = {0};
mip_filter_status_data                      filter_status               = {0};
mip_filter_linear_accel_data                filter_linear_accel         = {0};
mip_filter_comp_angular_rate_data           filter_angular_rate         = {0};
mip_filter_attitude_quaternion_data         filter_quaternion           = {0};
mip_filter_gravity_vector_data              filter_gravity              = {0};

/*********************************************************************
 * TYPEDEF ENUMS
 */

typedef enum rData_state
{
    START = 0,
    RESET_FILTER,
    CREATE_NEW_CVS,
    FINISH,
    START_UP,
    MIP_IDLE,
} rData_state;
/*********************************************************************
 * TYPEDEF STRUCTS
 */

// Estructura para mantener los archivos CSV abiertos
typedef struct {
    FILE *csv1;
    FILE *csv2;
    FILE *csv3;
} CsvFiles;

/*********************************************************************
 * PUBLIC FUNCTIONS
 */

uint64_t get_unix_time_ns(void); 

// Función para generar un nombre de archivo único
void generateFileName(char *baseName, int counter, char *fileName);

// Función para crear y abrir tres archivos CSV
CsvFiles createCsvFiles(void);

// Función para cerrar los archivos CSV
void closeCsvFiles(CsvFiles files);

// Función para escribir cadenas de texto formateadas en los archivos CSV
void writeDataToCsv(CsvFiles files, const char *line1, const char *line2, const char *line3);

// Función para guardar los datos en los archivos CSV creados
void saveDataToCsv(CsvFiles files, uint64_t *unix_ns);

// Función para encontrar el puerto del dispositivo basado en una palabra clave
char* find_device(const char* keyword);

/*********************************************************************
 * PRIVATE  FUNCTIONS
 */

// Custom logging handler callback
static void log_callback(void* _user, const microstrain_log_level _level, const char* _format, va_list _args);

// Capture gyro bias
static void capture_gyro_bias(mip_interface* _device);

// Sensor message format configuration
//static void configure_sensor_message_format(mip_interface* _device);

// Filter message format configuration
//static void configure_filter_message_format(mip_interface* _device);

// Event configuration
/* static void configure_event_triggers(mip_interface* _device);
static void configure_event_actions(mip_interface* _device);
static void enable_events(mip_interface* _device);
static void handle_event_triggers(void* _user, const mip_field_view* _field, mip_timestamp _timestamp);
 */
// Filter initialization
static void initialize_filter(mip_interface* _device);

// Utility to display filter state changes
static void display_filter_state(const mip_filter_mode _filter_state);

// Used for basic timestamping (since epoch in milliseconds)
// TODO: Update this to whatever timestamping method is desired
static mip_timestamp get_current_timestamp();

// Device callbacks used for reading and writing packets
static bool mip_interface_user_send_to_device(mip_interface* _device, const uint8_t* _data, size_t _length);
static bool mip_interface_user_recv_from_device(
    mip_interface* _device, uint8_t* _buffer, size_t _max_length, mip_timeout _wait_time, bool _from_cmd,
    size_t* _length_out, mip_timestamp* _timestamp_out
);

// Common device initialization procedure
static void initialize_device(mip_interface* _device, serial_port* _device_port, const uint32_t _baudrate);

// Utility functions the handle application closing and printing error messages
static void terminate(serial_port* _device_port, const char* _message, const bool _successful);

static void exit_from_command(const mip_interface* _device, const mip_cmd_result _cmd_result, const char* _format, ...);


int main(const int argc, const char* argv[])
{
    // Note: This is a compile-time way of checking that the proper logging level is enabled
    // Note: The max available logging level may differ in pre-packaged installations of the MIP SDK
    #ifndef MICROSTRAIN_LOGGING_ENABLED_INFO
    #error This example requires a logging level of at least MICROSTRAIN_LOGGING_LEVEL_INFO_ to work properly
    #endif // !MICROSTRAIN_LOGGING_ENABLED_INFO

    // Initialize the custom logger to print messages/errors as they occur
    // Note: The logging level parameter doesn't need to match the max logging level.
    // If the parameter is higher than the max level, higher-level logging functions will be ignored
    MICROSTRAIN_LOG_INIT(&log_callback, MICROSTRAIN_LOG_LEVEL_INFO, NULL);


    // Unused parameters
    // Unused parameters
  
    
    // Initialize the connection
    MICROSTRAIN_LOG_INFO("Initializing the connection.\n");
    serial_port device_port;
    serial_port_init(&device_port);

#if INDIVIDUAL_SCRIPT == 1

    (void)argc;
    (void)argv;

    BAUDRATE = 460800;

    char* PORT_NAME = find_device("FTDI");

    MICROSTRAIN_LOG_INFO(" Connecting to the device on port :%s ", PORT_NAME);

    MICROSTRAIN_LOG_INFO("Ingrese el baudrate que desea configurar: ");

    BAUDRATE = 0;

    if (scanf("%u", &BAUDRATE) != 1) {
        MICROSTRAIN_LOG_INFO("Invalid input\n");
        return 1;
    }

    MICROSTRAIN_LOG_INFO(" Baudrate set to : %u .\n", BAUDRATE);

#else

    BAUDRATE = 460800;

    if (argc < 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        return 1;
    }

    const char* PORT_NAME = argv[1];  // Usar argumento del padre
    MICROSTRAIN_LOG_INFO("Connecting to the device on port %s with %d baudrate.\n", PORT_NAME, BAUDRATE);
#endif


    // Open the connection to the device
    if (!serial_port_open(&device_port, PORT_NAME, BAUDRATE))
    {
        terminate(&device_port, "Could not open the connection!\n", false);
    }

    mip_interface device;
    initialize_device(&device, &device_port, BAUDRATE);


    #if SC_CONFIG == 0

    // Set accel a 8g
    mip_3dm_write_sensor_range(&device, MIP_SENSOR_RANGE_TYPE_ACCEL, 3);
    mip_3dm_save_sensor_range(&device, MIP_SENSOR_RANGE_TYPE_ACCEL);

    // Set gyro a 500 dps
    mip_3dm_write_sensor_range(&device, MIP_SENSOR_RANGE_TYPE_GYRO,3);
    mip_3dm_save_sensor_range(&device, MIP_SENSOR_RANGE_TYPE_GYRO);

    #endif
    
    // Capture gyro bias
    capture_gyro_bias(&device);
    mip_3dm_save_gyro_bias(&device); 

    // Configure the message format for sensor data
    //configure_sensor_message_format(&device);

    // Configure the message format for filter data
    // configure_filter_message_format(&device);

    // Setup event triggers/actions on > 45 degrees filter pitch and roll Euler angles
    // configure_event_triggers(&device);
    // configure_event_actions(&device);
    // enable_events(&device);
    mip_cmd_result cmd_result;
    #if SC_CONFIG == 0

    // Configure Sensor-to-Vehicle Transformation
    MICROSTRAIN_LOG_INFO("Configuring sensor-to-vehicle transformation.\n");
    cmd_result = mip_3dm_write_sensor_2_vehicle_transform_euler(
        &device,
        0.0f, // Roll
        0.0f, // Pitch
        0.0f  // Yaw
    );

    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(&device, cmd_result, "Could not configure sensor-to-vehicle transformation!\n");
    }

    #endif

    // Initialize the navigation filter
    initialize_filter(&device);

    MICROSTRAIN_LOG_INFO("Registering data callbacks.\n");


    mip_interface_register_extractor(&device, &sensor_data_handlers[0], MIP_SENSOR_DATA_DESC_SET, MIP_DATA_DESC_SHARED_GPS_TIME,         extract_mip_shared_gps_timestamp_data_from_field,          &sensor_gps_timestamp);
    mip_interface_register_extractor(&device, &sensor_data_handlers[1], MIP_SENSOR_DATA_DESC_SET, MIP_DATA_DESC_SENSOR_ACCEL_SCALED,     extract_mip_sensor_scaled_accel_data_from_field,           &sensor_accel_scaled);
    mip_interface_register_extractor(&device, &sensor_data_handlers[2], MIP_SENSOR_DATA_DESC_SET, MIP_DATA_DESC_SENSOR_DELTA_VELOCITY,   extract_mip_sensor_delta_velocity_data_from_field,         &sensor_delta_velocity);
    mip_interface_register_extractor(&device, &sensor_data_handlers[3], MIP_SENSOR_DATA_DESC_SET, MIP_DATA_DESC_SENSOR_COMP_QUATERNION,  extract_mip_sensor_comp_quaternion_data_from_field,        &sensor_quaternion);
    mip_interface_register_extractor(&device, &sensor_data_handlers[4], MIP_SENSOR_DATA_DESC_SET, MIP_DATA_DESC_SHARED_REFERENCE_TIME,   extract_mip_shared_reference_timestamp_data_from_field,    &sensor_inTime);
    // mip_interface_register_extractor(&device, &sensor_data_handlers[3], MIP_SENSOR_DATA_DESC_SET, MIP_DATA_DESC_SENSOR_GYRO_SCALED,      extract_mip_sensor_scaled_gyro_data_from_field,            &sensor_gyro_scaled);
    // mip_interface_register_extractor(&device, &sensor_data_handlers[4], MIP_SENSOR_DATA_DESC_SET, MIP_DATA_DESC_SENSOR_MAG_SCALED,       extract_mip_sensor_scaled_mag_data_from_field,             &sensor_mag_scaled);
    // mip_interface_register_extractor(&device, &sensor_data_handlers[5], MIP_SENSOR_DATA_DESC_SET, MIP_DATA_DESC_SENSOR_DELTA_THETA ,     extract_mip_sensor_delta_theta_data_from_field,            &sensor_delta_theta);
    MICROSTRAIN_LOG_INFO("Registering filter data callbacks.\n");

    mip_interface_register_extractor(&device, &filter_data_handlers[0], MIP_FILTER_DATA_DESC_SET, MIP_DATA_DESC_SHARED_GPS_TIME,                    extract_mip_shared_gps_timestamp_data_from_field,          &filter_gps_timestamp);
    mip_interface_register_extractor(&device, &filter_data_handlers[1], MIP_FILTER_DATA_DESC_SET, MIP_DATA_DESC_FILTER_LINEAR_ACCELERATION,         extract_mip_filter_linear_accel_data_from_field,            &filter_linear_accel);
    mip_interface_register_extractor(&device, &filter_data_handlers[2], MIP_FILTER_DATA_DESC_SET, MIP_DATA_DESC_FILTER_COMPENSATED_ANGULAR_RATE ,   extract_mip_filter_comp_angular_rate_data_from_field,       &filter_angular_rate);
    mip_interface_register_extractor(&device, &filter_data_handlers[3], MIP_FILTER_DATA_DESC_SET, MIP_DATA_DESC_FILTER_ATT_QUATERNION,              extract_mip_filter_attitude_quaternion_data_from_field,     &filter_quaternion );
    mip_interface_register_extractor(&device, &filter_data_handlers[4], MIP_FILTER_DATA_DESC_SET, MIP_DATA_DESC_FILTER_FILTER_STATUS,               extract_mip_filter_status_data_from_field,                  &filter_status);
    mip_interface_register_extractor(&device, &filter_data_handlers[5], MIP_FILTER_DATA_DESC_SET, MIP_DATA_DESC_FILTER_GRAVITY_VECTOR,              extract_mip_filter_gravity_vector_data_from_field,          &filter_gravity);
    // mip_interface_register_extractor(&device, &filter_data_handlers[1], MIP_FILTER_DATA_DESC_SET, MIP_DATA_DESC_FILTER_GYRO_BIAS,                   extract_mip_filter_gyro_bias_data_from_field,              &filter_gyro_bias);
    // Register a custom callback for the event field
    // mip_interface_register_field_callback( &device, &filter_data_handlers[5], MIP_FILTER_DATA_DESC_SET, MIP_DATA_DESC_SHARED_EVENT_SOURCE, handle_event_triggers, NULL);

    // Resume the device
    // Note: Since the device was idled for configuration, it needs to be resumed to output the data streams
    
    //mip_3dm_save_device_settings(&device);  

    //mip_interface_set_max_packets_per_update(&device, 1);
    
    MICROSTRAIN_LOG_INFO("Resuming the device.\n");
    cmd_result = mip_base_resume(&device);

    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(&device, cmd_result, "Could not resume the device!\n");
    }
    
    MICROSTRAIN_LOG_INFO("The device is configured... waiting for the filter to enter AHRS mode.\n");
    
    mip_filter_mode current_state = filter_status.filter_state;
    
        // Wait for the device to initialize
#if (MAGNETOMETER_FEATURE == 1)
    while (filter_status.filter_state < MIP_FILTER_MODE_AHRS)
#else
    while (filter_status.filter_state < MIP_FILTER_MODE_VERT_GYRO)
#endif
    {
        // Update the device state
        // Note: This will update the device callbacks to trigger the filter state change
        // Note: The recommended default wait time is 10 ms, but could be 0 for non-blocking read operations
        mip_interface_update(
            &device,
            10,   // Time to wait
            false // From command
        );
        
        // Filter state change
        if (current_state != filter_status.filter_state)
        {
            display_filter_state(filter_status.filter_state);
            current_state = filter_status.filter_state;
        }
    }
    
    int flags = fcntl(STDIN_FILENO, F_GETFL);
    fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);

    // Get the start time of the device update loop to handle exiting the application
    
    mip_timestamp previous_print_timestamp = 0;
    mip_timestamp current_timestamp = 0;
    
    mip_timestamp previous_print_idle = 0;
    mip_timestamp current_print_idle = 0;
    
    uint64_t unixTime = 0;
    
    rData_state rState = START;
    CsvFiles currentFiles;

    const mip_timestamp loop_start_time = get_current_timestamp();
    previous_print_idle = loop_start_time;




    static uint64_t last_printed_inTime = 0;
    
    while (1)
    {
        if(get_current_timestamp() - loop_start_time >= RUN_TIME_SECONDS * 1000) break; // Running loop . Exit after a predetermined time in seconds

        char c = 0;
        ssize_t n = read(STDIN_FILENO, &c, 1);

        if(n==1){

                if (c == 'n' || c == 'N') {
                    rState = CREATE_NEW_CVS;
                    MICROSTRAIN_LOG_INFO("Creating new INS files...\n");
                } 
                if (c == 'q' || c == 'Q')  {
                    rState = FINISH;
                    MICROSTRAIN_LOG_INFO("INS logging is finishing...\n");
                }
                if (c == 's' || c == 'S') {
                    rState = START_UP;
                    MICROSTRAIN_LOG_INFO("INS logging is starting up...\n");
                } 

                if (c == 'p' || c == 'P') {

                    flagStop = !flagStop;
                    MICROSTRAIN_LOG_INFO("Stop trigger\n");
                }
        }

        switch(rState)
        {
            case START:
                    MICROSTRAIN_LOG_INFO("INS logging  output data for %ds.\n", RUN_TIME_SECONDS);
                    currentFiles = createCsvFiles();
                    fileSetCounter++;
                    rState = MIP_IDLE;
            break;

            case CREATE_NEW_CVS:
                    {
                        flagStop = false;
                        MICROSTRAIN_LOG_INFO("Setting the INS device to idle.\n");
    
                        mip_cmd_result cmd_result = mip_base_set_idle(&device);
    
                        if (!mip_cmd_result_is_ack(cmd_result))
                        {
                            exit_from_command(&device, cmd_result, "Could not set the INS device to idle!\n");
                        }
    
                        
                        if (fileSetCounter > 1) {
                            MICROSTRAIN_LOG_INFO("Closing previous INS files...\n");
                            closeCsvFiles(currentFiles);
                        }
    
    
                        currentFiles = createCsvFiles();
    
                        fileSetCounter++;
                        MICROSTRAIN_LOG_INFO("INS files created.\n");
    
                        rState =RESET_FILTER;

                    }


            break;

            case RESET_FILTER:
                    {
                        MICROSTRAIN_LOG_INFO("Resetting the INS filter...\n");
                        mip_cmd_result cmd_result = mip_filter_reset(&device);
    
                        if (!mip_cmd_result_is_ack(cmd_result))
                        {
                            exit_from_command(&device, cmd_result, "Could not reset the INS filter!\n");
                        }

                        sleep(5); // Sleep for x second to allow the filter reset to process before resuming the device

                        MICROSTRAIN_LOG_INFO("Resuming the INS device.\n");
                        cmd_result = mip_base_resume(&device);

                        if (!mip_cmd_result_is_ack(cmd_result))
                        {
                            exit_from_command(&device, cmd_result, "Could not resume the INS device!\n");
                        }

                        rState = MIP_IDLE;
                    }

            break;


            case FINISH:
                    
                    {
                        if (fileSetCounter > 1) {
                            MICROSTRAIN_LOG_INFO("Closing previous INS files...\n");
                            closeCsvFiles(currentFiles);
                        }

                        MICROSTRAIN_LOG_INFO("Setting the INS device to idle.\n");
    
                        mip_cmd_result cmd_result = mip_base_set_idle(&device);
    
                        if (!mip_cmd_result_is_ack(cmd_result))
                        {
                            exit_from_command(&device, cmd_result, "Could not set the INS device to idle!\n");
                        }

                        goto go_out;  // Salir del bucle usando goto
                    }

            break;

            case START_UP:

                    // Update the device state
                    // Note: This will update the device callbacks to trigger the filter state change
                    // Note: The recommended default wait time is 10 ms, but could be 0 for non-blocking read operations
                    mip_interface_update(
                        &device,
                        0,   // Time to wait   
                        false // From command
                    );

                    // Filter state change
                    if (current_state != filter_status.filter_state)
                    {
                        display_filter_state(filter_status.filter_state);
                        current_state = filter_status.filter_state;
                    }
                    
                    current_timestamp = get_current_timestamp();
                    unixTime = current_timestamp;

                    
                    // Print out data based on the sample rate (1000 ms / SAMPLE_RATE_HZ)
                    if (current_timestamp - previous_print_timestamp >= 1000 / SAMPLE_RATE_HZ)
                    {
                        previous_print_timestamp = current_timestamp;
                    }
                    #if (MAGNETOMETER_FEATURE== 1)
                        if (filter_status.filter_state >= MIP_FILTER_MODE_AHRS)
                    #else
                    if (filter_status.filter_state >= MIP_FILTER_MODE_VERT_GYRO)
                    #endif            
                    {
                    }
                    if(sensor_inTime.nanoseconds != last_printed_inTime ){
                        last_printed_inTime = sensor_inTime.nanoseconds;
                        //MICROSTRAIN_LOG_INFO("Muestra 100Hz\n");
                        unixTime =get_current_timestamp();
                        saveDataToCsv(currentFiles, &unixTime);
                        // Track this TOW to avoid printing the same data again
                    }
            break;

            case MIP_IDLE:
                    current_print_idle = get_current_timestamp();
                    if(current_print_idle - previous_print_idle >= 60000){
                        MICROSTRAIN_LOG_INFO("Waiting the key 's' or 'S' to start INS logging.\n");
                        previous_print_idle = current_print_idle;
                    }

            break;

            default:
            break;
                    
        }

    }
    
    go_out:
    // Restoring stdin to blocking mode before exiting
    fcntl(STDIN_FILENO, F_SETFL, flags);
    terminate(&device_port, "INS logging completed successfully.\n", true);

    return 0;
}

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup _7_series_ahrs_example_c
/// @{
///

////////////////////////////////////////////////////////////////////////////////
/// @brief Custom logging callback for MIP SDK message formatting and output
///
/// @details Processes and formats log messages from the MIP SDK based on
///          severity level. Routes messages to appropriate output streams -
///          errors and fatal messages go to stderr while other levels go to
///          stdout. Each message is prefixed with its severity level name.
///
/// @param _user Pointer to user data (unused in this implementation)
/// @param _level Log message severity level from microstrain_log_level enum
/// @param _format Printf-style format string for the message
/// @param _args Variable argument list containing message parameters
///
///
static void log_callback(void* _user, const microstrain_log_level _level, const char* _format, va_list _args)
{
    // Unused parameter
    (void)_user;

    switch (_level)
    {
        case MICROSTRAIN_LOG_LEVEL_FATAL:
        case MICROSTRAIN_LOG_LEVEL_ERROR:
        {
            fprintf(stderr, "%s: ", microstrain_logging_level_name(_level));
            vfprintf(stderr, _format, _args);
            fflush(stderr);
            break;
        }
        case MICROSTRAIN_LOG_LEVEL_WARN:
        case MICROSTRAIN_LOG_LEVEL_INFO:
        case MICROSTRAIN_LOG_LEVEL_DEBUG:
        case MICROSTRAIN_LOG_LEVEL_TRACE:
        {
            fprintf(stdout, "%s: ", microstrain_logging_level_name(_level));
            vfprintf(stdout, _format, _args);
            fflush(stdout);
            break;
        }
        case MICROSTRAIN_LOG_LEVEL_OFF:
        default:
        {
            break;
        }
    }
}


////////////////////////////////////////////////////////////////////////////////
/// @brief Captures and configures device gyro bias
///
/// @param _device Pointer to the initialized MIP device interface
///
///
static void capture_gyro_bias(mip_interface* _device)
{
    // Get the command queue so we can increase the reply timeout during the capture duration,
    // then reset it afterward
    mip_cmd_queue*    cmd_queue        = mip_interface_cmd_queue(_device);
    const mip_timeout previous_timeout = mip_cmd_queue_base_reply_timeout(cmd_queue);
    MICROSTRAIN_LOG_INFO("Initial command reply timeout is %dms.\n", previous_timeout);

    // Note: The default is 15 s (15,000 ms)
    const uint16_t capture_duration            = CAPTURE_DURATION_TIME;
    const uint16_t increased_cmd_reply_timeout = capture_duration + 1000;

    MICROSTRAIN_LOG_INFO("Increasing command reply timeout to %dms for capture gyro bias.\n", increased_cmd_reply_timeout);
    mip_cmd_queue_set_base_reply_timeout(cmd_queue, increased_cmd_reply_timeout);

    mip_vector3f gyro_bias = {
        0.0f, // X
        0.0f, // Y
        0.0f  // Z
    };

    // Note: When capturing gyro bias, the device needs to remain still on a flat surface
    MICROSTRAIN_LOG_WARN("About to capture gyro bias for %.2g seconds!\n", (float)capture_duration / 1000.0f);
    MICROSTRAIN_LOG_WARN("Please do not move the device during this time!\n");
    // MICROSTRAIN_LOG_WARN("Press 'Enter' when ready...");

    // // Wait for anything to be entered
    // const int confirm_capture = getc(stdin);
    // (void)confirm_capture; // Unused

    MICROSTRAIN_LOG_WARN("Capturing gyro bias...\n");
    const mip_cmd_result cmd_result = mip_3dm_capture_gyro_bias(
        _device,
        capture_duration, // Capture duration (ms)
        gyro_bias         // Gyro bias out (result of the capture)
    );

    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(_device, cmd_result, "Failed to capture gyro bias!\n");
    }

    MICROSTRAIN_LOG_INFO("Capture gyro bias completed with result: [%f, %f, %f]\n", gyro_bias[0], gyro_bias[1], gyro_bias[2]);

    MICROSTRAIN_LOG_INFO("Reverting command reply timeout to %dms.\n", previous_timeout);
    mip_cmd_queue_set_base_reply_timeout(cmd_queue, previous_timeout);
}

/*
////////////////////////////////////////////////////////////////////////////////
/// @brief Configures message format for filter data streaming
///
/// @details Sets up filter data output by:
///          1. Querying device base rate
///          2. Validating desired sample rate against base rate
///          3. Calculating proper decimation
///          4. Configuring message format with:
///             - GPS timestamp
///             - Filter status
///             - Euler angles
///
/// @param _device Pointer to the initialized MIP device interface
///
///

static void configure_sensor_message_format(mip_interface* _device)
{
    // Note: Querying the device base rate is only one way to calculate the descriptor decimation
    // We could have also set it directly with information from the datasheet

    MICROSTRAIN_LOG_INFO("Getting the base rate for sensor data.\n");
    uint16_t       sensor_base_rate;
    mip_cmd_result cmd_result = mip_3dm_get_base_rate(
        _device,
        MIP_SENSOR_DATA_DESC_SET, // Data descriptor set
        &sensor_base_rate         // Base rate out
    );

    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(_device, cmd_result, "Could not get the base rate for filter data!\n");
    }

    // Supported sample rates can be any value from 1 up to the base rate
    // Note: Decimation can be anything from 1 to 65,565 (uint16_t::max)
    if (SAMPLE_RATE_HZ == 0 || SAMPLE_RATE_HZ > sensor_base_rate)
    {
        exit_from_command(
            _device,
            MIP_NACK_INVALID_PARAM,
            "Invalid sample rate of %dHz! Supported rates are [1, %d].\n",
            SAMPLE_RATE_HZ,
            sensor_base_rate
        );
    }

    // Calculate the decimation (stream rate) for the device based on its base rate
    // IMPORTANT: Decimation must be chosen to match desired rate as closely as possible
    // Actual rate will be: base_rate / decimation
    // For exact rate: decimation must divide base_rate evenly
    
    // Use user-specified decimation if set, otherwise calculate from SAMPLE_RATE_HZ
    uint16_t sensor_decimation;
    if (SENSOR_DECIMATION > 0)
    {
        sensor_decimation = SENSOR_DECIMATION;
        MICROSTRAIN_LOG_WARN("Using user-specified SENSOR_DECIMATION = %d\n", SENSOR_DECIMATION);
    }
    else
    {
        sensor_decimation = sensor_base_rate / SAMPLE_RATE_HZ;
    }
    
    const uint16_t actual_sensor_rate = sensor_base_rate / sensor_decimation;  // Calculate actual rate
    const uint16_t gps_time_decimation = sensor_decimation;  // Use same decimation for consistency
    
    MICROSTRAIN_LOG_INFO(
        "SENSOR: Base=%dHz | Decimation=%d | Actual Rate: %dHz (Requested: %dHz)%s\n",
        sensor_base_rate,
        sensor_decimation,
        actual_sensor_rate,
        SAMPLE_RATE_HZ,
        (actual_sensor_rate != SAMPLE_RATE_HZ) ? " [MISMATCH!]" : " [OK]"
    );

    if (actual_sensor_rate != SAMPLE_RATE_HZ)
    {
        MICROSTRAIN_LOG_WARN(
            "SENSOR RATE MISMATCH! Actual=%dHz vs Requested=%dHz\n",
            actual_sensor_rate,
            SAMPLE_RATE_HZ
        );
        MICROSTRAIN_LOG_WARN(
            "  Fix: Set SENSOR_DECIMATION=%d to get exact %dHz\n",
            sensor_base_rate / actual_sensor_rate,
            actual_sensor_rate
        );
        MICROSTRAIN_LOG_WARN(
        "  OR set SAMPLE_RATE_HZ=%d to match decimation %d\n",
            actual_sensor_rate,
            sensor_decimation
        );
    }
    else
    {
        MICROSTRAIN_LOG_INFO("  ✓ Sensor rate matches requested rate\n");
    }


    // Descriptor rate is a pair of data descriptor set and decimation
    const mip_descriptor_rate sensor_descriptors[5] = {
        {MIP_DATA_DESC_SHARED_GPS_TIME,         gps_time_decimation},
        {MIP_DATA_DESC_SENSOR_ACCEL_SCALED,     sensor_decimation},
        {MIP_DATA_DESC_SENSOR_DELTA_VELOCITY,   sensor_decimation},
        {MIP_DATA_DESC_SENSOR_COMP_QUATERNION,  sensor_decimation},
        {MIP_DATA_DESC_SHARED_REFERENCE_TIME,   sensor_decimation}
        // {MIP_DATA_DESC_SENSOR_GYRO_SCALED,      sensor_decimation},
        // {MIP_DATA_DESC_SENSOR_MAG_SCALED,       sensor_decimation},
        // {MIP_DATA_DESC_SENSOR_DELTA_THETA,      sensor_decimation},
    };

    MICROSTRAIN_LOG_INFO("Configuring message format for sensor data.\n");
    cmd_result = mip_3dm_write_message_format(
        _device,
        MIP_SENSOR_DATA_DESC_SET,                                   // Data descriptor set
        sizeof(sensor_descriptors) / sizeof(sensor_descriptors[0]), // Number of descriptors to include
        sensor_descriptors                                          // Descriptor array
    );

    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(_device, cmd_result, "Could not configure message format for sensor data!\n");
    }
}


////////////////////////////////////////////////////////////////////////////////
/// @brief Configures message format for filter data streaming
///
/// @details Sets up filter data output by:
///          1. Querying device base rate
///          2. Validating desired sample rate against base rate
///          3. Calculating proper decimation
///          4. Configuring message format with:
///             - GPS timestamp
///             - Filter status
///             - Euler angles
///
/// @param _device Pointer to the initialized MIP device interface
///
///
static void configure_filter_message_format(mip_interface* _device)
{
    // Note: Querying the device base rate is only one way to calculate the descriptor decimation
    // We could have also set it directly with information from the datasheet

    MICROSTRAIN_LOG_INFO("Getting the base rate for filter data.\n");
    uint16_t       filter_base_rate;
    mip_cmd_result cmd_result = mip_3dm_get_base_rate(
        _device,
        MIP_FILTER_DATA_DESC_SET, // Data descriptor set
        &filter_base_rate         // Base rate out
    );

    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(_device, cmd_result, "Could not get the base rate for filter data!\n");
    }

    // Supported sample rates can be any value from 1 up to the base rate
    // Note: Decimation can be anything from 1 to 65,565 (uint16_t::max)
    if (SAMPLE_RATE_HZ == 0 || SAMPLE_RATE_HZ > filter_base_rate)
    {
        exit_from_command(
            _device,
            MIP_NACK_INVALID_PARAM,
            "Invalid sample rate of %dHz! Supported rates are [1, %d].\n",
            SAMPLE_RATE_HZ,
            filter_base_rate
        );
    }

    // Calculate the decimation (stream rate) for the device based on its base rate
    // IMPORTANT: Decimation must be chosen to match desired rate as closely as possible
    // Actual rate will be: base_rate / decimation
    // For exact rate: decimation must divide base_rate evenly
    
    // Use user-specified decimation if set, otherwise calculate from SAMPLE_RATE_HZ
    uint16_t filter_decimation;
    if (FILTER_DECIMATION > 0)
    {
        filter_decimation = FILTER_DECIMATION;
        MICROSTRAIN_LOG_WARN("Using user-specified FILTER_DECIMATION = %d\n", FILTER_DECIMATION);
    }
    else
    {
        filter_decimation = filter_base_rate / SAMPLE_RATE_HZ;
    }
    
    const uint16_t actual_filter_rate = filter_base_rate / filter_decimation;  // Calculate actual rate
    const uint16_t filter_gps_time_decimation = filter_decimation;  // Use same decimation for consistency

    MICROSTRAIN_LOG_INFO(
        "FILTER: Base=%dHz | Decimation=%d | Actual Rate: %dHz (Requested: %dHz)%s\n",
        filter_base_rate,
        filter_decimation,
        actual_filter_rate,
        SAMPLE_RATE_HZ,
        (actual_filter_rate != SAMPLE_RATE_HZ) ? " [MISMATCH!]" : " [OK]"
    );

    if (actual_filter_rate != SAMPLE_RATE_HZ)
    {
        MICROSTRAIN_LOG_WARN(
            "FILTER RATE MISMATCH! Actual=%dHz vs Requested=%dHz\n",
            actual_filter_rate,
            SAMPLE_RATE_HZ
        );
        MICROSTRAIN_LOG_WARN(
            "  Fix: Set FILTER_DECIMATION=%d to get exact %dHz\n",
            filter_base_rate / actual_filter_rate,
            actual_filter_rate
        );
        MICROSTRAIN_LOG_WARN(
            "  OR set SAMPLE_RATE_HZ=%d to match decimation %d\n",
            actual_filter_rate,
            filter_decimation
        );
    }
    else
    {
        MICROSTRAIN_LOG_INFO("  ✓ Filter rate matches requested rate\n");
    }

    // Descriptor rate is a pair of data descriptor set and decimation
    const mip_descriptor_rate filter_descriptors[6] = {
        {MIP_DATA_DESC_SHARED_GPS_TIME,                     filter_gps_time_decimation},
        {MIP_DATA_DESC_FILTER_LINEAR_ACCELERATION,          filter_decimation},
        {MIP_DATA_DESC_FILTER_COMPENSATED_ANGULAR_RATE,     filter_decimation},
        {MIP_DATA_DESC_FILTER_ATT_QUATERNION,               filter_decimation},
        {MIP_DATA_DESC_FILTER_FILTER_STATUS,                filter_decimation},
        {MIP_DATA_DESC_FILTER_GRAVITY_VECTOR,               filter_decimation},
        // {MIP_DATA_DESC_FILTER_GYRO_BIAS,                    filter_decimation},
        // {MIP_DATA_DESC_SHARED_EVENT_SOURCE,                 filter_decimation},
    };


    MICROSTRAIN_LOG_INFO("Configuring message format for filter data.\n");
    cmd_result = mip_3dm_write_message_format(
        _device,
        MIP_FILTER_DATA_DESC_SET,                                   // Data descriptor set
        sizeof(filter_descriptors) / sizeof(filter_descriptors[0]), // Number of descriptors to include
        filter_descriptors                                          // Descriptor array
    );

    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(_device, cmd_result, "Could not configure message format for filter data!\n");
    }
}
    */

////////////////////////////////////////////////////////////////////////////////
/// @brief Configures threshold event triggers for roll and pitch angles
///
/// @details Sets up two event triggers for monitoring Euler angles:
///          1. Roll angle threshold (Trigger ID 1)
///             - Monitors X-axis rotation
///             - Triggers when the angle exceeds +/-45 degrees
///          2. Pitch angle threshold (Trigger ID 2)
///             - Monitors Y-axis rotation
///             - Triggers when the angle exceeds +/-45 degrees
///
/// @param _device Pointer to the initialized MIP device interface
///
///
// static void configure_event_triggers(mip_interface* _device)
// {
//     // Configure a threshold trigger
//     mip_3dm_event_trigger_command_parameters event_parameters;
//     event_parameters.threshold.desc_set   = MIP_FILTER_DATA_DESC_SET;
//     event_parameters.threshold.field_desc = MIP_DATA_DESC_FILTER_ATT_EULER_ANGLES;

//     // X-axis (roll)
//     event_parameters.threshold.param_id = 1;

//     // Configure the threshold as a trigger window
//     event_parameters.threshold.type = MIP_3DM_EVENT_TRIGGER_COMMAND_THRESHOLD_PARAMS_TYPE_WINDOW;

//     // Configure the high and low thresholds for the trigger window
//     // Note: The command expects radians for these values
//     event_parameters.threshold.low_thres  = 45.0 * M_PI / 180.0;                   // 45 degrees
//     event_parameters.threshold.high_thres = -event_parameters.threshold.low_thres; // -45 degrees

//     // Note: This is independent of the param_id
//     uint8_t trigger_instance_id = 1;

//     MICROSTRAIN_LOG_INFO("Configuring a threshold event trigger for roll on trigger instance ID %d.\n", trigger_instance_id);
//     mip_cmd_result cmd_result = mip_3dm_write_event_trigger(
//         _device,
//         trigger_instance_id,
//         MIP_3DM_EVENT_TRIGGER_COMMAND_TYPE_THRESHOLD, // Trigger type
//         &event_parameters                             // Trigger parameters to set
//     );

//     if (!mip_cmd_result_is_ack(cmd_result))
//     {
//         exit_from_command(_device, cmd_result, "Could not configure a threshold event trigger for roll!\n");
//     }

//     // Use the same trigger configuration, but set it to the y-axis (pitch)
//     event_parameters.threshold.param_id = 2;

//     // Note: This is independent of the param_id
//     trigger_instance_id = 2;

//     MICROSTRAIN_LOG_INFO("Configuring a threshold event trigger for pitch on trigger instance ID %d.\n", trigger_instance_id);
//     cmd_result = mip_3dm_write_event_trigger(
//         _device,
//         trigger_instance_id,
//         MIP_3DM_EVENT_TRIGGER_COMMAND_TYPE_THRESHOLD, // Trigger type
//         &event_parameters                             // Trigger parameters to set
//     );

//     if (!mip_cmd_result_is_ack(cmd_result))
//     {
//         exit_from_command(_device, cmd_result, "Could not configure a threshold event trigger for pitch!\n");
//     }
// }

////////////////////////////////////////////////////////////////////////////////
/// @brief Configures event actions to occur when triggers are activated
///
/// @details Sets up message actions for each event trigger:
///          - Links action instance 1 to trigger instance 1 (roll)
///          - Links action instance 2 to trigger instance 2 (pitch)
///          - Configures both to output event source data when triggered
///
/// @param _device Pointer to the initialized MIP device interface
///
///
// static void configure_event_actions(mip_interface* _device)
// {
//     mip_3dm_event_action_command_parameters event_action_parameters;
//     event_action_parameters.message.desc_set       = MIP_FILTER_DATA_DESC_SET;
//     event_action_parameters.message.decimation     = 0;
//     event_action_parameters.message.num_fields     = 1;
//     event_action_parameters.message.descriptors[0] = MIP_DATA_DESC_SHARED_EVENT_SOURCE;

//     // Note: These are independent of each other and do not need to be the same
//     // The tigger instance ID should match the configured trigger instance ID the action should be tied to
//     uint8_t action_instance_id  = 1;
//     uint8_t trigger_instance_id = 1;

//     MICROSTRAIN_LOG_INFO(
//         "Configuring message action instance ID %d for trigger instance ID %d (roll).\n",
//         action_instance_id,
//         trigger_instance_id
//     );
//     // Configure an action for event trigger 1 (roll)
//     mip_cmd_result cmd_result = mip_3dm_write_event_action(
//         _device,
//         action_instance_id,
//         trigger_instance_id,                       // Trigger instance ID to link to
//         MIP_3DM_EVENT_ACTION_COMMAND_TYPE_MESSAGE, // Action type
//         &event_action_parameters                   // Action parameters to set
//     );

//     if (!mip_cmd_result_is_ack(cmd_result))
//     {
//         exit_from_command(_device, cmd_result, "Could not configure a message action for the roll event trigger!\n");
//     }

//     // Note: These are independent of each other and do not need to be the same
//     // The tigger instance ID should match the configured trigger instance ID the action should be tied to
//     action_instance_id  = 2;
//     trigger_instance_id = 2;

//     MICROSTRAIN_LOG_INFO(
//         "Configuring message action instance ID %d for trigger instance ID %d (pitch).\n",
//         action_instance_id,
//         trigger_instance_id
//     );
//     // Configure an action for event trigger 2 (pitch)
//     cmd_result = mip_3dm_write_event_action(
//         _device,
//         action_instance_id,
//         trigger_instance_id,                       // Trigger instance ID to link to
//         MIP_3DM_EVENT_ACTION_COMMAND_TYPE_MESSAGE, // Action type
//         &event_action_parameters                   // Action parameters to set
//     );

//     if (!mip_cmd_result_is_ack(cmd_result))
//     {
//         exit_from_command(_device, cmd_result, "Could not configure a message action for the pitch event trigger!\n");
//     }
// }

////////////////////////////////////////////////////////////////////////////////
/// @brief Enables the configured event triggers
///
/// @details Activates both event triggers:
///          1. Enables roll threshold monitoring (Trigger ID 1)
///          2. Enables pitch threshold monitoring (Trigger ID 2)
///
/// @param _device Pointer to the initialized MIP device interface
///
///
// static void enable_events(mip_interface* _device)
// {
//     uint8_t event_trigger_instance_id = 1;

//     // Enable the roll event trigger
//     MICROSTRAIN_LOG_INFO("Enabling event trigger instance ID %d (roll).\n", event_trigger_instance_id);
//     mip_cmd_result cmd_result = mip_3dm_write_event_control(
//         _device,
//         event_trigger_instance_id,                 // Event trigger instance ID to enable
//         MIP_3DM_EVENT_CONTROL_COMMAND_MODE_ENABLED // Event control mode
//     );

//     if (!mip_cmd_result_is_ack(cmd_result))
//     {
//         exit_from_command(_device, cmd_result, "Could not enable event trigger for roll!\n");
//     }

//     event_trigger_instance_id = 2;

//     // Enable the pitch event trigger
//     MICROSTRAIN_LOG_INFO("Enabling event trigger instance ID %d (pitch).\n", event_trigger_instance_id);
//     cmd_result = mip_3dm_write_event_control(
//         _device,
//         event_trigger_instance_id,                 // Event trigger instance ID to enable
//         MIP_3DM_EVENT_CONTROL_COMMAND_MODE_ENABLED // Event control mode
//     );

//     if (!mip_cmd_result_is_ack(cmd_result))
//     {
//         exit_from_command(_device, cmd_result, "Could not enable event trigger for pitch!\n");
//     }
// }

////////////////////////////////////////////////////////////////////////////////
/// @brief Event handler for filter data source triggers
///
/// @details Processes event trigger notifications for:
///          - Roll threshold events (Trigger ID 1)
///          - Pitch threshold events (Trigger ID 2)
///          Outputs appropriate warning messages when thresholds are exceeded.
///
/// @param _user User data pointer (unused)
/// @param _field Pointer to the MIP field containing event data
/// @param _timestamp Timestamp of when the event occurred (unused)
///
///
// static void handle_event_triggers(void* _user, const mip_field_view* _field, mip_timestamp _timestamp)
// {
//     // Unused parameters
//     (void)_user;
//     (void)_timestamp;

//     mip_shared_event_source_data event_source;

//     if (!extract_mip_shared_event_source_data_from_field(_field, &event_source))
//     {
//         return;
//     }

//     // Event trigger instance ID 1 (roll)
//     if (event_source.trigger_id == 1)
//     {
//         MICROSTRAIN_LOG_WARN("Roll event triggered! Trigger ID: %d.\n", event_source.trigger_id);
//     }
//     // Event trigger instance ID 2 (pitch)
//     else if (event_source.trigger_id == 2)
//     {
//         MICROSTRAIN_LOG_WARN("Pitch event triggered! Trigger ID: %d.\n", event_source.trigger_id);
//     }
// }

////////////////////////////////////////////////////////////////////////////////
/// @brief Initializes and resets the navigation filter
///
/// @details Configures the filter by:
///          1. Enabling magnetometer aiding measurements
///          2. Resetting the filter to apply new settings
///
/// @param _device Pointer to the initialized MIP device interface
///
///
static void initialize_filter(mip_interface* _device)
{
    // Configure Filter Aiding Measurements
    
    mip_cmd_result cmd_result;

#if (MAGNETOMETER_FEATURE == 1)
    MICROSTRAIN_LOG_INFO("Enabling the aiding measurement source for magnetometer.\n");
    cmd_result = mip_filter_write_aiding_measurement_enable(
        _device,
        MIP_FILTER_AIDING_MEASUREMENT_ENABLE_COMMAND_AIDING_SOURCE_MAGNETOMETER, // Aiding Source type
        true                                                                // Enabled
    );
    
    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(_device, cmd_result, "Could not enable the aiding measurement source for magnetometer!\n");
    }

#else
    MICROSTRAIN_LOG_INFO("Disabling the aiding measurement source for magnetometer.\n");
    cmd_result = mip_filter_write_aiding_measurement_enable(
        _device,
        MIP_FILTER_AIDING_MEASUREMENT_ENABLE_COMMAND_AIDING_SOURCE_MAGNETOMETER, // Aiding Source type
        false                                                                // Disabled
    );

    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(_device, cmd_result, "Could not disable the aiding measurement source for magnetometer!\n");
    }
#endif  


    MICROSTRAIN_LOG_INFO("Disabling the aiding measurement source for external heading.\n");
    cmd_result = mip_filter_write_aiding_measurement_enable(
        _device,
         MIP_FILTER_AIDING_MEASUREMENT_ENABLE_COMMAND_AIDING_SOURCE_EXTERNAL_HEADING, // Aiding Source type
         false                                                                   // Disabled
    );


    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(_device, cmd_result, "Could not disable the aiding measurement source for external heading!\n");
    }


    // Reset the filter
    // Note: This is good to do after filter setup is complete
    MICROSTRAIN_LOG_INFO("Attempting to reset the navigation filter.\n");
    cmd_result = mip_filter_reset(_device);

    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(_device, cmd_result, "Could not reset the navigation filter!\n");
    }

}

////////////////////////////////////////////////////////////////////////////////
/// @brief Displays the current filter state when changes occur
///
/// @details Outputs readable messages for filter state transitions:
///          - Initialization mode
///          - Vertical gyro mode
///          - AHRS mode
///          - Full navigation mode
///
/// @param _filter_state Current filter mode from the MIP device interface
///
///
static void display_filter_state(const mip_filter_mode _filter_state)
{
    const char* mode_description = "startup";
    const char* mode_type        = "STARTUP";

    switch (_filter_state)
    {
        case MIP_FILTER_MODE_INIT:
        {
            mode_description = "initialization";
            mode_type        = "MIP_FILTER_MODE_INIT";
            break;
        }
        case MIP_FILTER_MODE_VERT_GYRO:
        {
            mode_description = "vertical gyro";
            mode_type        = "MIP_FILTER_MODE_VERT_GYRO";
            break;
        }
        case MIP_FILTER_MODE_AHRS:
        {
            mode_description = "AHRS";
            mode_type        = "MIP_FILTER_MODE_AHRS";
            break;
        }
        case MIP_FILTER_MODE_FULL_NAV:
        {
            mode_description = "full navigation";
            mode_type        = "MIP_FILTER_MODE_FULL_NAV";
            break;
        }
        default:
        {
            break;
        }
    }

    MICROSTRAIN_LOG_INFO("The filter has entered %s mode. (%d) %s\n", mode_description, (uint8_t)_filter_state, mode_type);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief Gets the current system timestamp in milliseconds
///
/// @details Provides basic timestamping using system time:
///          - Returns milliseconds since Unix epoch
///          - Uses timespec_get() with UTC time base
///          - Returns 0 if time cannot be obtained
///
/// @note Update this function to use a different time source if needed for
///       your specific application requirements
///
/// @return Current system time in milliseconds since epoch
///
///
static mip_timestamp get_current_timestamp()
{
    struct timespec ts;

    // Get system UTC time since epoch
    if (timespec_get(&ts, TIME_UTC) != TIME_UTC)
    {
        return 0;
    }

    // Get the time in milliseconds
    return (mip_timestamp)ts.tv_sec * 1000 + (mip_timestamp)ts.tv_nsec / 1000000;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief Handles sending packets to the device
///
/// @details Implements the MIP device interface send callback:
///          - Extracts serial port from device user pointer
///          - Validates connection state
///          - Writes data buffer to serial port
///
/// @param _device MIP device interface containing the connection
/// @param _data Buffer containing packet data to send
/// @param _length Number of bytes to send
///
/// @return True if send was successful, false otherwise
///
///
static bool mip_interface_user_send_to_device(mip_interface* _device, const uint8_t* _data, size_t _length)
{
    // Extract the serial port pointer that was used in the callback initialization
    serial_port* device_port = (serial_port*)mip_interface_user_pointer(_device);

    if (device_port == NULL)
    {
        MICROSTRAIN_LOG_ERROR("serial_port pointer not set in mip_interface_init().\n");
        return false;
    }

    // Get the bytes written to the device
    size_t bytes_written;

    // Send the packet to the device
    return serial_port_write(device_port, _data, _length, &bytes_written);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief Handles receiving packets from the device
///
/// @details Implements the MIP device interface receive callback:
///          - Extracts serial port from device user pointer
///          - Validates connection state
///          - Reads available data into provided buffer
///          - Timestamps the received data
///
/// @param _device MIP device interface containing the connection
/// @param _buffer Buffer to store received data
/// @param _max_length Maximum number of bytes to read
/// @param _wait_time How long to wait for data in milliseconds
/// @param _from_cmd Whether this read is from a command response (unused)
/// @param _length_out Number of bytes actually read
/// @param _timestamp_out Timestamp when data was received
///
/// @return True if receive was successful, false otherwise
///
///
static bool mip_interface_user_recv_from_device(
    mip_interface* _device, uint8_t* _buffer, size_t _max_length, mip_timeout _wait_time, bool _from_cmd,
    size_t* _length_out, mip_timestamp* _timestamp_out
)
{
    // Unused parameter
    (void)_from_cmd;

    // Extract the serial port pointer that was used in the callback initialization
    serial_port* device_port = (serial_port*)mip_interface_user_pointer(_device);

    if (device_port == NULL)
    {
        MICROSTRAIN_LOG_ERROR("serial_port pointer not set in mip_interface_init().\n");
        return false;
    }

    // Get the time that the packet was received (system epoch UTC time in milliseconds)
    *_timestamp_out = get_current_timestamp();

    // Read the packet from the device
    return serial_port_read(device_port, _buffer, _max_length, (int)_wait_time, _length_out);
}



////////////////////////////////////////////////////////////////////////////////
/// @brief Initializes and configures a MIP device interface
///
/// @details Performs a complete device initialization sequence:
///          1. Sets up a MIP device interface with specified timeouts and
///             callbacks
///          2. Verifies device communication with a ping command
///          3. Sets the device to idle mode to ensure reliable configuration
///          4. Queries and displays detailed device information
///          5. Loads default device settings for a known state
///
/// @param _device Pointer to a MIP device interface to initialize
/// @param _device_port Pointer to an initialized serial port for device
///                     communication
/// @param _baudrate Serial communication baudrate for the device
///
///
static void initialize_device(mip_interface* _device, serial_port* _device_port, const uint32_t _baudrate)
{
    MICROSTRAIN_LOG_INFO("Initializing the device interface.\n");
    

    mip_interface_init(
        _device,
        mip_timeout_from_baudrate(_baudrate), // Set the base timeout for commands (milliseconds)
        2000,                                 // Set the base timeout for command replies (milliseconds)
        &mip_interface_user_send_to_device,   // User-defined send packet callback
        &mip_interface_user_recv_from_device, // User-defined receive packet callback
        &mip_interface_default_update,        // Default update callback
        (void*)_device_port                   // Cast the device port for use in the callbacks
    );
    

    // Ping the device
    // Note: This is a good first step to make sure the device is present
    MICROSTRAIN_LOG_INFO("Pinging the device.\n");
    mip_cmd_result cmd_result = mip_base_ping(_device);

    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(_device, cmd_result, "Could not ping the device!\n");
    }

    // Set the device to Idle
    // Note: This is good to do during setup as high data traffic can cause commands to fail
    MICROSTRAIN_LOG_INFO("Setting the device to idle.\n");
    cmd_result = mip_base_set_idle(_device);

    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(_device, cmd_result, "Could not set the device to idle!\n");
    }

    // Print device info to make sure the correct device is being used
    MICROSTRAIN_LOG_INFO("Getting the device information.\n");
    mip_base_device_info device_info;
    cmd_result = mip_base_get_device_info(_device, &device_info);

    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(_device, cmd_result, "Could not get the device information!\n");
    }

    // Extract the major minor and patch values
    const uint16_t major = device_info.firmware_version / 1000;
    const uint16_t minor = device_info.firmware_version / 100 % 10;
    const uint16_t patch = device_info.firmware_version % 100;

    // Firmware version format is x.x.xx
    char firmwareVersion[16] = {0};
    snprintf(firmwareVersion, sizeof(firmwareVersion) / sizeof(firmwareVersion[0]), "%d.%d.%02d", major, minor, patch);

    MICROSTRAIN_LOG_INFO("-------- Device Information --------\n");
    MICROSTRAIN_LOG_INFO("%-16s | %.16s\n", "Name", device_info.model_name);
    MICROSTRAIN_LOG_INFO("%-16s | %.16s\n", "Model Number", device_info.model_number);
    MICROSTRAIN_LOG_INFO("%-16s | %.16s\n", "Serial Number", device_info.serial_number);
    MICROSTRAIN_LOG_INFO("%-16s | %.16s\n", "Lot Number", device_info.lot_number);
    MICROSTRAIN_LOG_INFO("%-16s | %.16s\n", "Options", device_info.device_options);
    MICROSTRAIN_LOG_INFO("%-16s | %16s\n", "Firmware Version", firmwareVersion);
    MICROSTRAIN_LOG_INFO("------------------------------------\n");

    // Load the default settings on the device
    // Note: This guarantees the device is in a known state
    // MICROSTRAIN_LOG_INFO("Loading device default settings.\n");
    // cmd_result = mip_3dm_default_device_settings(_device);

#if DEFAULT_CONFIG == 1 && SC_CONFIG == 0

    MICROSTRAIN_LOG_INFO("Loading device default settings.\n");
    cmd_result = mip_3dm_default_device_settings(_device);

    if (!mip_cmd_result_is_ack(cmd_result))
    {
        // Note: Default settings will reset the baudrate to 115200 and may cause connection issues
        if (cmd_result == MIP_STATUS_TIMEDOUT && BAUDRATE != 115200)
        {
            MICROSTRAIN_LOG_WARN("On a native serial connections the baudrate needs to be 115200 for this example to run.\n");
        }

        exit_from_command(_device, cmd_result, "Could not load device default settings!\n");
    }

    mip_3dm_write_uart_baudrate(_device, 460800);
        
    mip_3dm_save_uart_baudrate(_device);

    sleep(1); // wait to save the baudrate

    // uint32_t baudRead =0;

    // mip_3dm_read_uart_baudrate(_device, &baudRead);

    // MICROSTRAIN_LOG_INFO("Read Baudrate %u.\n", &baudRead);
#elif DEFAULT_CONFIG == 0 && SC_CONFIG == 0

    MICROSTRAIN_LOG_INFO("Loading device settings.\n");
    cmd_result = mip_3dm_load_device_settings(_device);
    
    if (!mip_cmd_result_is_ack(cmd_result))
    {
        // Note: Default settings will reset the baudrate to 115200 and may cause connection issues
    //        if (cmd_result == MIP_STATUS_TIMEDOUT && BAUDRATE != 115200)
        if (cmd_result == MIP_STATUS_TIMEDOUT )
        {
            MICROSTRAIN_LOG_WARN("On a native serial connections the baudrate needs to be 115200 for this example to run.\n");
        }
    
        exit_from_command(_device, cmd_result, "Could not load device default settings!\n");
    }


    mip_3dm_write_uart_baudrate(_device, 460800);
        
    mip_3dm_save_uart_baudrate(_device);

    sleep(1); // wait to save the baudrate
    // Reset the filter
    // Note: This is good to do after filter setup is complete
    MICROSTRAIN_LOG_INFO("Attempting to reset the navigation filter.\n");

    cmd_result = mip_filter_reset(_device);
    
    if (!mip_cmd_result_is_ack(cmd_result))
    {
        exit_from_command(_device, cmd_result, "Could not reset the navigation filter!\n");
    }
#endif

}



////////////////////////////////////////////////////////////////////////////////
/// @brief Handles graceful program termination and cleanup
///
/// @details Handles graceful shutdown when errors occur:
///          - Outputs provided error message
///          - Closes device connection if open
///          - Exits with appropriate status code
///
/// @param _device_port Serial port connection to close
/// @param _message Error message to display
/// @param _successful Whether termination is due to success or failure
///
///
static void terminate(serial_port* _device_port, const char* _message, const bool _successful)
{
    if (_message != NULL && strlen(_message) != 0)
    {
        if (_successful)
        {
            MICROSTRAIN_LOG_INFO("%s", _message);
        }
        else
        {
            MICROSTRAIN_LOG_ERROR("%s", _message);
        }
    }

    if (_device_port == NULL)
    {
        // Initialize the device interface with a serial port connection
        MICROSTRAIN_LOG_ERROR("Connection not set for the device interface. Cannot close the connection.\n");
    }
    else
    {
        if (serial_port_is_open(_device_port))
        {
            MICROSTRAIN_LOG_INFO("Closing the connection.\n");

            if (!serial_port_close(_device_port))
            {
                MICROSTRAIN_LOG_ERROR("Failed to close the connection!\n");
            }
        }
    }

    // MICROSTRAIN_LOG_INFO("Press 'Enter' to exit the program.\n");
    MICROSTRAIN_LOG_INFO("Exit the program.\n");

    // Make sure the console remains open
    // const int confirm_exit = getc(stdin);
    // (void)confirm_exit; // Unused

    if (!_successful)
    {
        exit(1);
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief Handles graceful program termination and command failure cleanup
///
/// @details Handles command failure scenarios:
///          - Formats and displays an error message with command result
///          - Closes device connection
///          - Exits with failure status
///
/// @param _device MIP device interface for the command that failed
/// @param _cmd_result Result code from a failed command
/// @param _format Printf-style format string for error message
/// @param ... Variable arguments for format string
///
///
static void exit_from_command(const mip_interface* _device, const mip_cmd_result _cmd_result, const char* _format, ...)
{
    if (_format != NULL && strlen(_format) != 0)
    {
        va_list args;
        va_start(args, _format);
        MICROSTRAIN_LOG_ERROR_V(_format, args);
        va_end(args);
    }

    MICROSTRAIN_LOG_ERROR("Command Result: (%d) %s.\n", _cmd_result, mip_cmd_result_to_string(_cmd_result));

    if (_device == NULL)
    {
        terminate(NULL, "", false);
    }
    else
    {
        // Get the connection pointer that was set during device initialization
        serial_port* device_port = (serial_port*)mip_interface_user_pointer(_device);

        terminate(device_port, "", false);
    }
}

uint64_t get_unix_time_ns() {
    struct timespec ts;

    // Obtiene el tiempo actual en segundos y nanosegundos desde la época UNIX (1 de enero de 1970)
    clock_gettime(CLOCK_REALTIME, &ts);

    // Devuelve el tiempo en nanosegundos (segundos * 1e9 + nanosegundos)
    return (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
}

void generateFileName(char *baseName, int counter, char *fileName) {
    sprintf(fileName, "%s_%d.csv", baseName, counter);
}

CsvFiles createCsvFiles() {
    CsvFiles files;
    char fileName[MAX_FILENAME_LENGTH];

    // Generar nombres para los tres archivos
    generateFileName("SensorConnectData_", fileSetCounter, fileName);
    files.csv1 = fopen(fileName, "w");
    if (files.csv1 == NULL) {
        perror("Error to open file 1");
        exit(1);
    }

    //CSV Header 
    fprintf(files.csv1, 
            "Time,GPS_ts,fGPS_ts,"
            "scaledAccelX,scaledAccelY,scaledAccelZ,"
            "deltaVelX,deltaVelY,deltaVelZ,"
            "estLinearAccelX,estLinearAccelY,estLinearAccelZ,estLinearAccel:valid,"
            "estAngularRateX,estAngularRateY,estAngularRateZ,estAngularRate:valid,"
            "estGravityX,estGravityY,estGravityZ,estGravity:valid,"
            "flag\n");

    generateFileName("Quaternion_", fileSetCounter, fileName);
    files.csv2 = fopen(fileName, "w");
    if (files.csv2 == NULL) {
        perror("Error to open file 2");
        exit(1);
    }

    fprintf(files.csv2, 
            "Time,GPS_ts,"
            "orientQuaternion[0],"
            "orientQuaternion[1],"
            "orientQuaternion[2],"
            "orientQuaternion[3],flag\n");

    generateFileName("QuaternionEst_", fileSetCounter, fileName);
    files.csv3 = fopen(fileName, "w");
    if (files.csv3 == NULL) {
        perror("Error to open file 3");
        exit(1);
    }

    fprintf(files.csv3, 
            "Time,fGPS_ts,"
            "estOrientQuaternion[0],"
            "estOrientQuaternion[1],"
            "estOrientQuaternion[2],"
            "estOrientQuaternion[3],"
            "estOrientQuaternion:valid,flag\n");

    return files;
}

void closeCsvFiles(CsvFiles files) {
    if (files.csv1) fclose(files.csv1);
    if (files.csv2) fclose(files.csv2);
    if (files.csv3) fclose(files.csv3);
}

// Función para escribir cadenas de texto formateadas en los archivos CSV
void writeDataToCsv(CsvFiles files, const char *line1, const char *line2, const char *line3) {
    fputs(line1, files.csv1);
    fputs(line2, files.csv2);
    fputs(line3, files.csv3);
}

void saveDataToCsv(CsvFiles files, uint64_t* unix_ns){

    memset(buffer0,0,BUFFER0_SIZE);
    memset(buffer1,0,BUFFER1_SIZE);
    memset(buffer2,0,BUFFER2_SIZE);

    uint8_t flag = 0;

    if(flagStop) flag = 1;
    else flag = 0;

    snprintf(   buffer0,
                BUFFER0_SIZE,
                "%" PRIu64 "," 
                "%10.3f,%10.3f,"                               
                "%9.6f,%9.6f,%9.6f,"
                "%9.6f,%9.6f,%9.6f,"
                "%9.6f,%9.6f,%9.6f,%u,"
                "%9.6f,%9.6f,%9.6f,%u,"
                "%9.6f,%9.6f,%9.6f,%u,"                                             
                "%u\n",                                                        
                *unix_ns,
                sensor_gps_timestamp.tow,
                filter_gps_timestamp.tow,                                                                                            
                sensor_accel_scaled.scaled_accel[0], sensor_accel_scaled.scaled_accel[1], sensor_accel_scaled.scaled_accel[2], 
                sensor_delta_velocity.delta_velocity[0], sensor_delta_velocity.delta_velocity[1], sensor_delta_velocity.delta_velocity[2],
                filter_linear_accel.accel[0], filter_linear_accel.accel[1], filter_linear_accel.accel[2], filter_linear_accel.valid_flags,
                filter_angular_rate.gyro[0], filter_angular_rate.gyro[1], filter_angular_rate.gyro[2], filter_angular_rate.valid_flags, 
                filter_gravity.gravity[0], filter_gravity.gravity[1], filter_gravity.gravity[2], filter_gravity.valid_flags,
                (unsigned int)flag
            );



    snprintf(   buffer1,
                BUFFER1_SIZE,
                "%" PRIu64 ","                              
                "%10.3f,"                             
                "%9.6f,%9.6f,%9.6f,%9.6f,"
                "%u\n",                                                         
                *unix_ns, 
                sensor_gps_timestamp.tow,                                                                                        
                sensor_quaternion.q[0], sensor_quaternion.q[1], sensor_quaternion.q[2], sensor_quaternion.q[3], 
                (unsigned int)flag                                  
            );



    snprintf(   buffer2,
                BUFFER2_SIZE,
                "%" PRIu64 ","     
                "%10.3f,"                          
                "%9.6f,%9.6f,%9.6f,%9.6f,%u,"                                                          
                "%u\n",                                                          
                *unix_ns,    
                filter_gps_timestamp.tow,                                                                                         
                filter_quaternion.q[0], filter_quaternion.q[1], filter_quaternion.q[2], filter_quaternion.q[3], filter_quaternion.valid_flags,
                (unsigned int)flag                                 
            );


    writeDataToCsv(files, buffer0 ,buffer1, buffer2);



}


char* find_device(const char* keyword) {
    static char result[MAX_PATH];
    const char* base = "/dev/serial/by-id/";

    DIR* dir = opendir(base);
    if (!dir) {
        perror("opendir");
        return NULL;
    }

    struct dirent* entry;

    while ((entry = readdir(dir)) != NULL) {
        if (strstr(entry->d_name, keyword) != NULL) {
            snprintf(result, MAX_PATH, "%s%s", base, entry->d_name);
            closedir(dir);
            return result;
        }
    }

    closedir(dir);
    return NULL;
}